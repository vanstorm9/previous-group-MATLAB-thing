function a = featuresdim(),
a = 32; % how many features are in the HOG cell
