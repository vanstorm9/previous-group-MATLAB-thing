function switchabin(a)
global picx
global picy
global binframe
switch a
case 1
picx='46';  
picy='545';
binframe=[357 1 618 421];
case 2  
picx='0';  
picy='620';
binframe=[362 1 601 389];
case 3  
picx='0';  
picy='625';
binframe=[365 4 593 378];
case 4
picx='0';  
picy='625';
binframe=[365 1 580 383];
case 5
picx='118';  
picy='370';
binframe=[338 4 628 416];
case 6  
picx='0';  
picy='620';
binframe=[338 1 615 394];
case 7
picx='0';  
picy='625';
binframe=[340 1 599 394];
case 8
picx='0';  
picy='625';
binframe=[340 1 588 394];
case 9
picx='113';  
picy='0';
binframe=[330 1 607 392];
case 10
picx='0';  
picy='125';
binframe=[330 1 607 392];
case 11
picx='0';  
picy='125';
binframe=[335 4 631 389];
case 12
picx='0';  
picy='120';
binframe=[343 1 626 418];
end