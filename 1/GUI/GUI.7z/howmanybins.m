function howmanybins( )%%empty
global x
global y
global z
global s
startmotor
status='finish start'
takeemptypicture(12)
fclose(s); 
fclose(x);
fclose(y);
fclose(z);