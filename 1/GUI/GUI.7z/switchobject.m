function switchobject(a)
global picn
global pich
global picnub
picnub=a;
switch a
case 1
    picn=8;
    pich=2;
case 2
    picn=9;
case 3
    picn=6;
    pich=4;
case 4
    picn=5;
    pich=1;
case 5
    picn=4;
    pich=2;
case 6
    picn=3;
    pich=4;
case 7
    picn=6;
case 8
    picn=2;
case 9
    picn=3;    
    pich=2;
case 10
    picn=7;    
case 11
    picn=3;
case 12
    picn=6;
    pich=3;
case 13
    picn=4;
    pich=5;
case 14
    picn=3;
    pich=3;
case 15
    picn=6;
    pich=3;
case 16
    picn=5;
    pich=4;
case 17
    picn=5;
case 18
    picn=8;
case 19
    picn=5;
    pich=3;     
case 20
    picn=1;
case 21
    picn=1;
    pich=7;   
end